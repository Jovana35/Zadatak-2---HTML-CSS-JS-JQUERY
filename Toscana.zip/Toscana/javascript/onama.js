var el_up = document.getElementById("btn1")
var el_down = document.getElementById("p1")
function preciNaParagraf(){
    $(window).scrollTop($('#p1').position().top);
}