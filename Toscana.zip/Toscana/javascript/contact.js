function validacijaForme() { 

    var name = document.forms["RegForm"]["ime"]; 
    var email = document.forms["RegForm"]["email"];    
    var sto = document.forms["RegForm"]["sto"];
    var napomena = document.forms["RegForm"]["napomena"];
    var datum = document.forms["RegForm"]["datum"];

    function fun(){ 
        name.value="";
        email.value="";
        napomena.value="";
    }


    if (name.value == "" || email.value == "" || sto.selectedIndex < 1 || datum.value== "") { 
        window.alert("Molimo vas unesite sve podatke, ispravno"); 
        name.focus();
        email.focus();
        sto.focus();
        return false; 
    } 
   
    window.alert("Uspešno ste rezervisali mesto");
    return true; 
}