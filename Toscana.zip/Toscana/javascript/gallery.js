function slike(imgs) { 
    var prosiritiSliku = document.getElementById("prosiriti"); 
    var tekstSlike = document.getElementById("restoran"); 
    prosiritiSliku.src = imgs.src; 
    tekstSlike.innerHTML = imgs.alt; 
    prosiritiSliku.parentElement.style.display = "block"; 
}